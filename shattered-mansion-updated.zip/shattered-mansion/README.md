# SHATTERED — Detective Mystery

A browser-based first-person detective mystery built with Three.js.

## Run locally
Use a local web server because the project uses JavaScript modules:
- `python3 -m http.server 8000`
- Open `http://localhost:8000`

## Controls
### Laptop / desktop
- WASD or arrow keys: move
- Mouse: look around (click the scene to capture the mouse)
- F: toggle torch
- Click an evidence object in the centre of the view to inspect it
- Escape: release the mouse / close an open panel

### Phone / tablet
- Left virtual pad: move
- Drag the scene: look around
- Tap an evidence object in the centre of the view to inspect it

## Cases
Six standalone mysteries, each with its own location, cast, evidence trail, required proof chain and reveal:
1. The Last Light — Blackthorn Lighthouse
2. A Room Without Echo — The Orpheum Theatre
3. The Glass Orchard — Aster Conservatory
4. The Winter Archive — Northglass Estate
5. The Silent Platform — Platform Nine
6. The Pale Blue Letter — The Bellweather Hotel

## Notes
- The home screen is intentionally pitch black; the investigation scene is illuminated primarily by the player's torch.
- Graphics are procedural in this build, including the atmospheric cloud fall sequence, dust, room materials and evidence props.
- The interface asks the player to identify their device before entering a case and adapts the controls accordingly.
