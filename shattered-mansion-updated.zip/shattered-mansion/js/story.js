
export const CASES = [
{
 id:"01", title:"THE LAST LIGHT", place:"Blackthorn Lighthouse", mood:"Storm / isolation",
 intro:"At 11:16 PM, the lighthouse beam stopped turning. By dawn, keeper Elias Rook was found dead in the locked lantern room. The storm erased the footprints outside. Everyone swears the light was working when they last saw it.",
 plot:"The lighthouse was sealed from the inside. The official report calls it an accident. But the logbook has a missing page, the lens is clean on one side only, and the foghorn sounded twice when the power was supposedly out.",
 suspects:[
  ["Mara Voss","Assistant keeper","I was in the generator room. The light failed before I went upstairs."],
  ["Jonas Reed","Harbour pilot","I never came ashore. My boat was tied at the eastern pier."],
  ["Ivo Crane","Maintenance engineer","The mechanism was already damaged. I warned Elias weeks ago."],
  ["Nell Rook","Elias's daughter","We argued, yes. I left before the storm reached the island."]
 ],
 clues:[
  ["log","The logbook","The final page was removed cleanly. Pressure marks on the next page preserve the words: 'second rotation — 11:05'."],
  ["lens","The Fresnel lens","A crescent of fresh grease sits on the inner brass ring. The outer ring is dusty."],
  ["rope","The service rope","Saltwater on the rope is dry at the knot but wet along the middle. It was handled after the storm began."],
  ["bell","The foghorn ledger","Two manual horn signals are recorded at 11:12. The power meter shows a complete outage at 11:09."],
  ["key","The duplicate key","The key cabinet seal is unbroken, but the inventory count is off by one. The missing key was returned before dawn."]
 ],
 killer:"ivo", proof:["lens","bell","key"], reveal:"Ivo used the service access during the brief interval before the storm peaked. The grease pattern proves the lens was manually stopped, not damaged by the outage. The horn ledger places him at the control room after the power failed; the duplicate-key count disproves his claim that no one could enter. He staged the locked-room puzzle to hide that he had been inside."
},
{
 id:"02", title:"A ROOM WITHOUT ECHO", place:"The Orpheum Theatre", mood:"Dust / velvet / silence",
 intro:"During the final rehearsal, celebrated stage director Celeste Vale vanished from a locked dressing room. An hour later, the theatre's old echo chamber was found sealed. Her final note reads: 'Listen to what isn't there.'",
 plot:"Five people had access to the stage. Each remembers hearing the rehearsal bell. The recording contains the bell, but the orchestra was silent at that exact moment.",
 suspects:[
  ["Rhea Sol","Lead actor","I was on stage. The entire company saw me."],
  ["Miles Arden","Sound designer","The recording is authentic. I checked it myself."],
  ["Tomas Bell","Stage manager","I locked the corridor after the bell."],
  ["June Vale","Celeste's sister","I came to collect a coat. I never went near the stage."]
 ],
 clues:[
  ["record","Rehearsal recording","The bell rings over a stretch of tape hiss. The room tone changes for exactly four seconds."],
  ["script","Marked script","A cue is circled in blue pencil, but the stage manager's copy has no such mark."],
  ["dust","Dressing-room dust","A clean rectangle beneath the mirror suggests a heavy object was recently moved."],
  ["ticket","Seat ticket","A ticket stub is dated for tomorrow's performance, but the seat was removed years ago."],
  ["cable","Sound cable","The cable labelled LIVE feeds the archive deck, not the stage speakers."]
 ],
 killer:"miles", proof:["record","cable","script"], reveal:"Miles played the bell from the archive deck and used the false cue to make everyone remember a sound that never came from the stage. The four-second room-tone shift matches the archive machine starting. His own cable label leads to the only device that could create the illusion. The missing echo was the clue: the bell was never in the room."
},
{
 id:"03", title:"THE GLASS ORCHARD", place:"Aster Conservatory", mood:"Moonlight / glass / rain",
 intro:"Botanist Dr. Sera Wynn collapsed during a private midnight tour of the glasshouse. The doors were still locked at sunrise. Every guest insists they stayed in the central gallery, yet wet footprints lead away from it and stop at a dry patch.",
 plot:"The conservatory's climate system records every door opening. Its archive shows no entry after midnight, but the humidity chart tells a different story.",
 suspects:[
  ["Ada Finch","Head gardener","I was pruning in the west wing all evening."],
  ["Pavel Orin","Architect","I designed the glasshouse. I know every service passage."],
  ["Lio Wynn","Research assistant","I left my notes on the central table and went home."],
  ["Etta Moss","Night curator","I never left the control desk."]
 ],
 clues:[
  ["humidity","Humidity chart","A sudden dry pocket appears in the east wing while the doors remain logged as closed."],
  ["footprints","Wet footprints","The prints stop at a floor panel whose dust is disturbed along one edge."],
  ["blueprint","Original blueprint","A service corridor was removed from the public plans, but remains in the maintenance copy."],
  ["tag","Plant tag","The tag was rewritten in a different ink. Its date is three days older than the plant itself."],
  ["clock","Wall clock","The clock is seven minutes slow, matching the climate system's manual override delay."]
 ],
 killer:"pavel", proof:["humidity","blueprint","clock"], reveal:"Pavel used the concealed service corridor, which bypassed the door sensors. The humidity chart records the corridor's ventilation cycle; the seven-minute clock drift aligns exactly with the manual override. The public blueprint was deliberately altered, but the maintenance copy exposes the route. The wet prints were a planted distraction."
},
{
 id:"04", title:"THE WINTER ARCHIVE", place:"Northglass Estate", mood:"Snow / candlelight / paper",
 intro:"Archivist Edmund Vale was discovered in the sealed records room after the estate's annual snowbound gathering. A priceless letter is missing. The windows are iced shut and the only key was on the steward's desk.",
 plot:"The family says the letter was never in the room. Yet its empty frame has a fresh shadow, and the fireplace ash contains a fragment bearing the estate's old seal.",
 suspects:[
  ["Cora Vale","Estate heir","I was cataloguing the family portraits."],
  ["Bram Holt","Steward","The key never left my desk."],
  ["Dr. Nils","Family historian","I came for the letter, not for Edmund."],
  ["Mina Ash","Restorer","I repaired the frame last month. It was already empty."]
 ],
 clues:[
  ["frame","Empty frame","The dust line shows the letter was removed after the room was cleaned."],
  ["ash","Fireplace ash","A corner of the missing letter survived. The seal is intact, but the paper is modern."],
  ["wax","Desk seal","The wax impression is a perfect copy, including a tiny flaw from the original stamp."],
  ["snow","Window ledge","Snow lies undisturbed outside, but meltwater is present on the inner sill."],
  ["catalogue","Restoration catalogue","The frame's backing was replaced two days ago, not last month."]
 ],
 killer:"mina", proof:["frame","catalogue","wax"], reveal:"Mina had the frame open during the unrecorded restoration visit. The new backing was fitted two days ago, allowing the letter to be removed without touching the locked door. The wax copy came from the original stamp flaw she had access to while restoring it. The snow and ash were staged to suggest a window escape and a destroyed original."
},
{
 id:"05", title:"THE SILENT PLATFORM", place:"Platform Nine", mood:"Rain / neon / midnight",
 intro:"At 00:03, the night station announcer broadcast a train that never arrived. Station controller Arun Das disappeared between two camera sweeps. No train entered the station, but a fresh ticket was punched at the empty platform.",
 plot:"The CCTV clocks disagree by ninety seconds. The timetable has been altered in pencil. One platform speaker is still warm, though the station power was cut.",
 suspects:[
  ["Nisha Roy","Ticket inspector","I checked the last passengers and went home."],
  ["Dev Malik","Signal operator","The signal board never changed."],
  ["Rafi Sen","Night cleaner","I was mopping the west stairs."],
  ["Leena Das","Controller's colleague","Arun asked me to cover his shift. I refused."]
 ],
 clues:[
  ["cctv","Camera timestamps","Three cameras drift by different amounts. Their shared event is the platform clock chime."],
  ["ticket","Punched ticket","The punch mark is reversed. It was made with the inspector's spare device."],
  ["speaker","Platform speaker","The casing is warm, but its dust pattern shows it was moved from the control booth."],
  ["timetable","Pencil timetable","The erased departure was written with a carpenter's pencil, not the station issue."],
  ["signal","Signal board","The indicator never changed because the display was replaying yesterday's diagnostic loop."]
 ],
 killer:"dev", proof:["cctv","speaker","signal"], reveal:"Dev used the diagnostic loop to make the signal board appear live while the real system was isolated. The camera drift only makes sense when aligned to the platform chime, exposing the false timeline. The warm speaker was moved from the control booth, where Dev had access. The reversed ticket is a deliberate false lead toward Nisha."
},
{
 id:"06", title:"THE PALE BLUE LETTER", place:"The Bellweather Hotel", mood:"Fog / mirrors / old money",
 intro:"Hotel owner Victor Bellweather received a letter at 8:40 PM and cancelled every reservation for the night. At 9:10, he was found dead in the conservatory. The letter was gone. Every guest claims the corridor was empty.",
 plot:"The hotel's mirrored corridors create false sightlines. A bell rang at 8:55, but the desk register records no visitor. The room-service tray returned untouched, except for one detail.",
 suspects:[
  ["Iris Bell","Hotel manager","I was at reception from eight until close."],
  ["Owen Pike","Bellweather's solicitor","I delivered papers and left immediately."],
  ["Sana Grey","Guest pianist","I played in the lounge. Ask the guests."],
  ["Felix Ward","Night porter","I carried no letters that evening."]
 ],
 clues:[
  ["mirror","Corridor mirror","The mirror reflects a door that is actually a service alcove. Its angle was changed recently."],
  ["register","Guest register","A line was erased, but the pressure marks show the initials F.W."],
  ["bell","Service bell","The bell's wire runs to the old laundry, not reception."],
  ["tray","Room-service tray","The tray returned untouched, but its paper liner has a rectangular ink transfer."],
  ["letter","Letter envelope","A pale blue fibre is caught in the seal. The hotel's laundry uses only white paper."]
 ],
 killer:"felix", proof:["mirror","register","bell"], reveal:"Felix altered the mirror angle to create a blind spot, then used the service alcove. The erased register line preserves his initials under pressure. The bell did not ring at reception; it was triggered from the laundry route he controlled. The blue fibre and ink transfer establish the letter's journey, while the untouched tray rules out the supposed room-service meeting."
}
];
