import * as THREE from 'three';
import {CASES} from './story.js';
const $=s=>document.querySelector(s);
const scene=new THREE.Scene();scene.background=new THREE.Color(0x000000);scene.fog=new THREE.FogExp2(0x000000,.055);
const camera=new THREE.PerspectiveCamera(72,innerWidth/innerHeight,.1,180);
const renderer=new THREE.WebGLRenderer({canvas:$('#world'),antialias:true,powerPreference:'high-performance'});
renderer.setPixelRatio(Math.min(devicePixelRatio,1.7));renderer.shadowMap.enabled=true;renderer.shadowMap.type=THREE.PCFSoftShadowMap;
renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=.8;
const hemi=new THREE.HemisphereLight(0x243044,0x080706,.035);scene.add(hemi);
const torch=new THREE.SpotLight(0xffe2b7,100,27,Math.PI/7,.5,1.3);torch.position.set(0,0,0);torch.target.position.set(0,0,-1);camera.add(torch,torch.target);scene.add(camera);
const fill=new THREE.PointLight(0x9a6b49,.22,5);camera.add(fill);
let device='desktop',deviceChosen=false,pendingIntent='play',activeCase=CASES[0],found=new Set(),yaw=0,pitch=0,paused=false,gameOn=false,torchOn=true,shake=0,quality='high',sens=1,torchPower=2,clock=new THREE.Clock(),toastTimer,move={x:0,z:0};
let meshes=[],clueMeshes=[],roomMeshes=[],dust=[],keys={};
scene.add(new THREE.AmbientLight(0x0a0a0a,.08));
const mat=(color,rough=.9,metal=0)=>new THREE.MeshStandardMaterial({color,roughness:rough,metalness:metal});
function clearWorld(){for(const o of [...roomMeshes,...clueMeshes,...dust])scene.remove(o);roomMeshes=[];clueMeshes=[];dust=[]}
function addBox(w,h,d,x,y,z,m,group=roomMeshes){const o=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),m);o.position.set(x,y,z);o.castShadow=true;o.receiveShadow=true;scene.add(o);group.push(o);return o}
function makeNoiseTexture(base,accent){const c=document.createElement('canvas');c.width=c.height=256;const x=c.getContext('2d');x.fillStyle=base;x.fillRect(0,0,256,256);for(let i=0;i<2400;i++){x.globalAlpha=Math.random()*.12;x.fillStyle=accent;x.fillRect(Math.random()*256,Math.random()*256,Math.random()*5+1,Math.random()*5+1)}const t=new THREE.CanvasTexture(c);t.wrapS=t.wrapT=THREE.RepeatWrapping;t.repeat.set(4,4);return t}
function buildWorld(){
 clearWorld();const palettes=[
  [0x222b35,0x171a20,0x806c52],[0x302329,0x191317,0x825a4a],[0x27332e,0x101916,0x738d78],
  [0x35302a,0x191713,0x9b835e],[0x252b36,0x11151c,0x497d9a],[0x302c38,0x16121c,0x8a789c]];
 const p=palettes[(+activeCase.id-1)%palettes.length],wall=new THREE.MeshStandardMaterial({color:p[0],map:makeNoiseTexture('#77716a','#c2b8a6'),roughness:.97}),floorMat=new THREE.MeshStandardMaterial({map:makeNoiseTexture('#272522','#b3a28a'),roughness:.95}),trim=mat(p[2],.65,.25);
 addBox(24,.5,24,0,-.35,0,floorMat);addBox(24,9,.5,0,4.2,-12,wall);addBox(24,9,.5,0,4.2,12,wall);addBox(.5,9,24,-12,4.2,0,wall);addBox(.5,9,24,12,4.2,0,wall);
 // ceiling beams and architectural depth
 for(let x=-9;x<=9;x+=6){addBox(.22,.35,24,x,8.2,0,trim);addBox(24,.18,.22,0,7.8,x,trim)}
 for(let z=-8;z<=8;z+=4){addBox(23,.08,.08,0,.02,z,trim)}
 // case-specific atmosphere props
 for(let i=0;i<8;i++){const x=(i%4-1.5)*5.5,z=Math.floor(i/4)*12-6;addBox(.18,4,.18,x,2,z,trim);addBox(2.8,.18,.18,x,3.8,z,trim)}
 // broken window slits and distant warm practicals
 for(let i=0;i<5;i++){const x=-9+i*4.5;const w=addBox(1.5,2.5,.08,x,5.2,-11.72,mat(0x090d12,.4,.2));const glow=new THREE.PointLight(p[2],.5,5);glow.position.set(x,5,-10.5);scene.add(glow);roomMeshes.push(glow)}
 // atmospheric drifting dust
 const geo=new THREE.BufferGeometry(),arr=new Float32Array(420*3);for(let i=0;i<420;i++){arr[i*3]=(Math.random()-.5)*22;arr[i*3+1]=Math.random()*8;arr[i*3+2]=(Math.random()-.5)*22}geo.setAttribute('position',new THREE.BufferAttribute(arr,3));const pts=new THREE.Points(geo,new THREE.PointsMaterial({color:0xc9b99d,size:.025,transparent:true,opacity:.24}));scene.add(pts);dust.push(pts);
 // five physical evidence objects, each with distinct silhouette/material
 const colors=[0xb58c59,0x8295a3,0x8b564e,0xb7b1a2,0x6d8878];
 activeCase.clues.forEach((cl,i)=>{
  const a=i/5*Math.PI*2-Math.PI/2,x=Math.cos(a)*7.1,z=Math.sin(a)*7.1;
  const g=new THREE.Group();g.position.set(x,.25,z);g.userData={clue:cl};
  const base=mat(colors[i],.62,.12),dark=mat(0x171514);
  let obj;
  if(i===0){obj=new THREE.Mesh(new THREE.BoxGeometry(.65,.07,.48),base);obj.rotation.y=.3;obj.position.y=.5}
  else if(i===1){obj=new THREE.Mesh(new THREE.CylinderGeometry(.12,.18,.8,12),base);obj.position.y=.6}
  else if(i===2){obj=new THREE.Mesh(new THREE.BoxGeometry(.55,.55,.08),base);obj.position.y=.55;obj.rotation.y=.5}
  else if(i===3){obj=new THREE.Mesh(new THREE.TorusGeometry(.28,.07,8,18),base);obj.position.y=.65;obj.rotation.x=Math.PI/2}
  else{obj=new THREE.Mesh(new THREE.OctahedronGeometry(.36,0),base);obj.position.y=.65}
  obj.castShadow=true;g.add(obj);
  const pin=new THREE.Mesh(new THREE.SphereGeometry(.07,8,8),new THREE.MeshBasicMaterial({color:0xd9b77f}));pin.position.y=1.05;g.add(pin);
  const light=new THREE.PointLight(0xc99c60,.32,2.8);light.position.y=1.15;g.add(light);
  scene.add(g);clueMeshes.push(g);
 });
 camera.position.set(0,1.7,10);yaw=0;pitch=0;camera.rotation.set(0,yaw,0,'YXZ');
}
function openModal(id){$(id).classList.remove('hidden');paused=true}
function closeModal(id){$(id).classList.add('hidden');paused=false}
function notify(s){const e=$('#toast');e.textContent=s;e.classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>e.classList.remove('show'),2800)}
function setHome(){gameOn=false;$('#game').classList.add('hidden');$('#home').classList.remove('hidden');$('#cases').classList.add('hidden');$('#settings').classList.add('hidden');$('#device').classList.add('hidden');}
function fillCases(){const g=$('#caseGrid');g.innerHTML=CASES.map((c,i)=>`<button class="case-card" data-case="${i}"><small>CASE ${c.id} · ${c.mood.toUpperCase()}</small><strong>${c.title}</strong><span>${c.place} → OPEN FILE</span></button>`).join('');g.querySelectorAll('[data-case]').forEach(b=>b.onclick=()=>startCase(CASES[+b.dataset.case]))}
function showDevice(intent='play'){pendingIntent=intent;openModal('#device')}
function startCase(c){activeCase=c;found.clear();buildWorld();$('#caseName').textContent=c.title;$('#evidenceCount').textContent='0';$('#objective b').textContent=c.intro;$('#home').classList.add('hidden');$('#cases').classList.add('hidden');$('#device').classList.add('hidden');$('#game').classList.remove('hidden');$('#roomNav').innerHTML='<button class="active" id="sceneBtn">SCENE 01 · MAIN HALL</button><button id="storyBtn">CASE BRIEF</button>';$('#sceneBtn').onclick=()=>notify('You are already in the primary scene.');$('#storyBtn').onclick=brief;gameOn=true;paused=false;camera.position.set(0,1.7,10);yaw=0;pitch=0;camera.rotation.set(0,yaw,0,'YXZ');$('#mobileControls').classList.toggle('hidden',device==='desktop');if(device==='desktop'&&renderer.domElement.requestPointerLock)renderer.domElement.requestPointerLock();fallSequence();setTimeout(()=>{if(gameOn)brief()},3000)}
function makeCloudTexture(){const c=document.createElement('canvas');c.width=c.height=256;const x=c.getContext('2d');const g=x.createRadialGradient(128,128,8,128,128,126);g.addColorStop(0,'rgba(225,231,238,.62)');g.addColorStop(.35,'rgba(176,188,202,.34)');g.addColorStop(.72,'rgba(110,125,145,.12)');g.addColorStop(1,'rgba(40,48,60,0)');x.fillStyle=g;x.fillRect(0,0,256,256);for(let i=0;i<150;i++){x.globalAlpha=Math.random()*.07;x.fillStyle='#fff';x.beginPath();x.arc(Math.random()*256,Math.random()*256,Math.random()*28+5,0,Math.PI*2);x.fill()}return new THREE.CanvasTexture(c)}
function fallSequence(){const el=$('#fall');el.classList.remove('hidden');const tex=makeCloudTexture(),clouds=[];for(let i=0;i<46;i++){const m=new THREE.Mesh(new THREE.PlaneGeometry(8+Math.random()*13,5+Math.random()*8),new THREE.MeshBasicMaterial({map:tex,transparent:true,opacity:.35+Math.random()*.35,depthWrite:false,side:THREE.DoubleSide}));m.position.set((Math.random()-.5)*28,2+Math.random()*34,(Math.random()-.5)*24);m.rotation.z=Math.random()*Math.PI;scene.add(m);clouds.push(m)}let elapsed=0;const startY=34;camera.position.set(0,startY,10);shake=1.5;const flick=setInterval(()=>{if(!gameOn){clearInterval(flick);return}$('#flash').style.opacity=Math.random()*.22;torch.intensity=torchOn?(Math.random()>.28?100*torchPower:2):0;if(Math.random()>.45)shake=Math.max(shake,.8)},58);const drop=()=>{if(!gameOn){clouds.forEach(c=>scene.remove(c));clearInterval(flick);return}elapsed+=.035;const k=Math.min(1,elapsed);camera.position.y=THREE.MathUtils.lerp(startY,1.7,k*k);camera.position.x=Math.sin(elapsed*27)*.14*(1-k);camera.position.z=10+Math.cos(elapsed*19)*.12*(1-k);clouds.forEach((c,i)=>{c.position.y-=.34+(i%5)*.04;c.material.opacity=Math.max(0,c.material.opacity-.003);c.lookAt(camera.position)});if(k<1)requestAnimationFrame(drop);else{clouds.forEach(c=>scene.remove(c));el.classList.add('hidden');$('#flash').style.opacity=0;clearInterval(flick);torch.intensity=100*torchPower;camera.position.set(0,1.7,10);notify('You have arrived. Find what the darkness is hiding.')}};requestAnimationFrame(drop)}
function brief(){panel(`<p class="eyebrow">CASE ${activeCase.id} · INCIDENT REPORT</p><h3>${activeCase.title}</h3><p>${activeCase.plot}</p><p><b>LOCATION:</b> ${activeCase.place}</p><div class="action-row"><button id="briefClose">RETURN TO SCENE</button><button id="briefBoard">OPEN CASE BOARD</button></div>`);$('#briefClose').onclick=()=>closeModal('#panel');$('#briefBoard').onclick=board}
function panel(html){$('#panelContent').innerHTML=html;openModal('#panel')}
function inspect(g){const c=g.userData.clue;if(found.has(c[0])){notify('Already documented in your evidence log.');return}found.add(c[0]);$('#evidenceCount').textContent=found.size;g.scale.setScalar(1.22);setTimeout(()=>g.scale.setScalar(1),180);panel(`<p class="eyebrow">EVIDENCE RECOVERED · ${found.size}/5</p><h3>${c[1]}</h3><p>${c[2]}</p><p class="credit">This evidence has been pinned to your case board.</p><div class="action-row"><button id="eClose">CONTINUE INVESTIGATION</button><button id="eBoard">VIEW CASE BOARD</button></div>`);$('#eClose').onclick=()=>closeModal('#panel');$('#eBoard').onclick=board}
function notebook(){const clues=activeCase.clues.filter(c=>found.has(c[0]));panel(`<p class="eyebrow">FIELD NOTES</p><h3>COLLECTED EVIDENCE · ${found.size}/5</h3>${clues.length?clues.map(c=>`<div class="clue"><b>${c[1]}</b><p>${c[2]}</p></div>`).join(''):'<p>Your notebook is empty. Explore the room and inspect the objects marked by a faint glint.</p>'}<div class="action-row"><button id="nClose">CLOSE</button><button id="nBoard">CASE BOARD</button></div>`);$('#nClose').onclick=()=>closeModal('#panel');$('#nBoard').onclick=board}
function board(){const clues=activeCase.clues.filter(c=>found.has(c[0]));const connections=clues.length>1?'<p class="credit">The red thread marks a possible connection. Compare timing, access and contradictions before accusing anyone.</p>':'';const pins=clues.length?clues.map((c,i)=>`<span class="pin" style="transform:rotate(${i%2?2:-2}deg)">${c[1]}</span>`).join(''):'<p>No evidence pinned yet.</p>';panel(`<p class="eyebrow">INVESTIGATION WALL</p><h3>THE CASE BOARD</h3><div class="stringboard"><svg viewBox="0 0 900 180" preserveAspectRatio="none" style="position:absolute;inset:0;width:100%;height:100%;pointer-events:none"><path d="M25 35 L230 78 L420 28 L620 105 L870 48 M230 78 L420 145 L620 105" stroke="#9d3737" stroke-width="2" fill="none" opacity=".85"/><circle cx="25" cy="35" r="4" fill="#d8c29f"/><circle cx="230" cy="78" r="4" fill="#d8c29f"/><circle cx="420" cy="28" r="4" fill="#d8c29f"/><circle cx="620" cy="105" r="4" fill="#d8c29f"/><circle cx="870" cy="48" r="4" fill="#d8c29f"/></svg>${pins}</div>${connections}<div class="action-row"><button id="bClose">BACK</button><button id="bSus">QUESTION SUSPECTS</button><button id="bAcc">MAKE ACCUSATION</button></div>`);$('#bClose').onclick=()=>closeModal('#panel');$('#bSus').onclick=suspects;$('#bAcc').onclick=accuse}function suspects(){panel(`<p class="eyebrow">INTERROGATION ROOM</p><h3>THE PEOPLE WHO WERE THERE</h3>${activeCase.suspects.map((s,i)=>`<div class="suspect"><b>${s[0]}</b><small> · ${s[1]}</small><p>“${s[2]}”</p><button data-sus="${i}">CHALLENGE STATEMENT</button><div id="reply${i}"></div></div>`).join('')}<div class="action-row"><button id="sClose">CLOSE</button><button id="sBoard">CASE BOARD</button></div>`);$('#sClose').onclick=()=>closeModal('#panel');$('#sBoard').onclick=board;$('#panelContent').querySelectorAll('[data-sus]').forEach(b=>b.onclick=()=>{const i=+b.dataset.sus,el=$('#reply'+i),s=activeCase.suspects[i];if(!found.size)el.innerHTML='<p class="credit">You need evidence before challenging this statement.</p>';else el.innerHTML=`<p class="credit">You place your collected evidence on the table. ${s[0]} studies it, then changes the subject. Their account has been added to your notes for comparison.</p>`})}
function accuse(){const options=activeCase.suspects.map((s,i)=>`<option value="${s[0].toLowerCase().split(' ')[0]}">${s[0]}</option>`).join('');panel(`<p class="eyebrow">FINAL DEDUCTION</p><h3>NAME THE PERSON RESPONSIBLE</h3><p>You need the complete proof chain. A guess is not a conclusion.</p><label>YOUR ACCUSATION<select id="accused">${options}</select></label><p class="credit">Required evidence: ${activeCase.proof.map(id=>activeCase.clues.find(c=>c[0]===id)[1]).join(' · ')}</p><div class="action-row"><button id="aBack">NOT YET</button><button id="aSubmit">SUBMIT DEDUCTION</button></div>`);$('#aBack').onclick=()=>closeModal('#panel');$('#aSubmit').onclick=()=>{const complete=activeCase.proof.every(k=>found.has(k));if(!complete){notify('Your proof chain is incomplete. Revisit the scene.');return}const val=$('#accused').value;if(val===activeCase.killer){caseSolved()}else{notify('The evidence does not support that accusation. Re-examine the contradictions.');shake=.7}}}
function caseSolved(){const c=activeCase;panel(`<p class="eyebrow">CASE CLOSED · ${c.id}</p><h3>THE TRUTH, AT LAST.</h3><p>${c.reveal}</p><p class="credit">All required evidence was accounted for. The timeline, access and contradictions now form one consistent explanation.</p><div class="action-row"><button id="nextCase">NEXT CASE</button><button id="homeBtn">MAIN MENU</button></div>`);$('#nextCase').onclick=()=>{const i=CASES.indexOf(c);startCase(CASES[(i+1)%CASES.length])};$('#homeBtn').onclick=()=>{document.exitPointerLock?.();setHome()}}
function toggleTorch(){torchOn=!torchOn;torch.intensity=torchOn?100*torchPower:0;$('#torchLabel').innerHTML=`TORCH <i>${torchOn?'● ON':'○ OFF'}</i>`}
$('#playBtn').onclick=()=>showDevice('play');$('#caseBtn').onclick=()=>showDevice('cases');$('#settingsBtn').onclick=()=>openModal('#settings');$('#deviceBack').onclick=()=>closeModal('#device');
document.querySelectorAll('[data-close]').forEach(b=>b.onclick=()=>closeModal('#'+b.dataset.close));
document.querySelectorAll('[data-device]').forEach(b=>b.onclick=()=>{device=b.dataset.device;deviceChosen=true;closeModal('#device');if(pendingIntent==='cases'){fillCases();openModal('#cases')}else startCase(CASES[0])});
$('#torchLabel').onclick=toggleTorch;$('#notebookBtn').onclick=notebook;$('#boardBtn').onclick=board;$('#suspectBtn').onclick=suspects;$('#pauseBtn').onclick=()=>panel(`<p class="eyebrow">INVESTIGATION PAUSED</p><h3>TAKE A MOMENT.</h3><div class="action-row"><button id="resume">RESUME</button><button id="pNotes">EVIDENCE</button><button id="pHome">EXIT TO MENU</button></div>`);
$('#quality').onchange=e=>{quality=e.target.value;renderer.setPixelRatio(Math.min(devicePixelRatio,quality==='high'?1.7:quality==='balanced'?1.2:1))};$('#sensitivity').oninput=e=>sens=+e.target.value;$('#torchPower').oninput=e=>{torchPower=+e.target.value;torch.intensity=torchOn?100*torchPower:0};$('#shakeToggle').onchange=e=>window.shakeEnabled=e.target.checked;

addEventListener('keydown',e=>{keys[e.code]=true;if(e.code==='KeyF'&&gameOn&&!paused)toggleTorch();if(e.code==='Escape'&&gameOn&&!$('#panel').classList.contains('hidden'))closeModal('#panel')});
addEventListener('keyup',e=>keys[e.code]=false);
let pointer=false,lastX=0,lastY=0;
renderer.domElement.addEventListener('click',()=>{if(device==='desktop'&&gameOn&&!paused&&document.pointerLockElement!==renderer.domElement)renderer.domElement.requestPointerLock?.()});
document.addEventListener('pointerlockchange',()=>pointer=document.pointerLockElement===renderer.domElement);
document.addEventListener('mousemove',e=>{if(pointer&&gameOn&&!paused){yaw-=e.movementX*.002*sens;pitch=Math.max(-1.2,Math.min(1.2,pitch-e.movementY*.002*sens))}});
renderer.domElement.addEventListener('pointerdown',e=>{if(device!=='desktop'){lastX=e.clientX;lastY=e.clientY}});
renderer.domElement.addEventListener('pointermove',e=>{if(device!=='desktop'&&e.buttons&&gameOn&&!paused){yaw-=(e.clientX-lastX)*.004*sens;pitch=Math.max(-1.2,Math.min(1.2,pitch-(e.clientY-lastY)*.004*sens));lastX=e.clientX;lastY=e.clientY}});
renderer.domElement.addEventListener('pointerup',e=>{if(!gameOn||paused)return;const r=new THREE.Raycaster();r.setFromCamera(new THREE.Vector2(0,0),camera);const hits=r.intersectObjects(clueMeshes,true);if(hits.length&&hits[0].distance<5){let o=hits[0].object;while(o.parent&&!o.userData.clue)o=o.parent;if(o.userData.clue)inspect(o)}});
$('#lookHelp').onclick=()=>notify('Drag anywhere on the scene to look around. Use the left pad to move.');
// virtual joystick
let stickDown=false;$('#stick').addEventListener('pointerdown',e=>{stickDown=true;$('#stick').setPointerCapture(e.pointerId)});$('#stick').addEventListener('pointermove',e=>{if(!stickDown)return;const r=$('#stick').getBoundingClientRect(),dx=(e.clientX-r.left-r.width/2)/(r.width/2),dy=(e.clientY-r.top-r.height/2)/(r.height/2);move.x=Math.max(-1,Math.min(1,dx));move.z=Math.max(-1,Math.min(1,dy));$('#knob').style.transform=`translate(${move.x*28}px,${move.z*28}px)`});$('#stick').addEventListener('pointerup',()=>{stickDown=false;move={x:0,z:0};$('#knob').style.transform=''});
function animate(){requestAnimationFrame(animate);const dt=Math.min(clock.getDelta(),.04);if(gameOn&&!paused){
 let f=(keys.KeyW||keys.ArrowUp?1:0)-(keys.KeyS||keys.ArrowDown?1:0)+(-move.z),s=(keys.KeyD||keys.ArrowRight?1:0)-(keys.KeyA||keys.ArrowLeft?1:0)+move.x;
 const dir=new THREE.Vector3(s,0,-f);if(dir.lengthSq()>0){dir.normalize().applyAxisAngle(new THREE.Vector3(0,1,0),yaw);camera.position.addScaledVector(dir,dt*3.0)}
 camera.position.x=THREE.MathUtils.clamp(camera.position.x,-10.5,10.5);camera.position.z=THREE.MathUtils.clamp(camera.position.z,-10.5,10.5);
 camera.rotation.set(pitch,yaw,0,'YXZ');
 // flashlight follows view direction
 const pos=dust[0]?.geometry.attributes.position;if(pos){for(let i=0;i<pos.count;i++){let y=pos.getY(i)+dt*.08;if(y>8)y=0;pos.setY(i,y)}pos.needsUpdate=true}
 if(torchOn)torch.intensity=(90+Math.sin(performance.now()*.008)*4)*torchPower;
 }
 if(gameOn&&shake>.01&&window.shakeEnabled!==false){camera.position.x+=(Math.random()-.5)*shake*.055;camera.position.y+=(Math.random()-.5)*shake*.045;shake*=.9}else shake*=.9;renderer.render(scene,camera)}
function resize(){camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();renderer.setSize(innerWidth,innerHeight)}
addEventListener('resize',resize);
 $('#panelContent').addEventListener('click',e=>{if(e.target.id==='resume')closeModal('#panel');if(e.target.id==='pNotes')notebook();if(e.target.id==='pHome'){document.exitPointerLock?.();setHome()}});
setTimeout(()=>{$('#boot').classList.add('hidden');$('#home').classList.remove('hidden')},1450);
animate();
